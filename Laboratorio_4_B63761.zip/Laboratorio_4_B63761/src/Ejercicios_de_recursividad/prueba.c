#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <string.h>



int palindromo(char *string, int size)
{
    if (size <= 0)
        return 1;
    else if (string[0] == string[size - 1])
        return palindromo(&string[1], size - 2);
    else
        return 0;
}

char* screen(char string[])
{
  int i,j,result, length;
  char *newstring[50];
  length = strlen(string);
  for(i=0,j=0;i<length;i++)
      if (string[i] != ' ')
      {
          newstring[j] = string[i];
          j++;
      }
  newstring[j] = '\0';
  length = strlen(newstring);

    return newstring;
}

char *substring(int i,int j,char *ch)
{
  int k=0;
  // avoid calc same things several time
  int n = j-i+1;
  char *ch1;
  // you can omit casting - and sizeof(char) := 1
  ch1=malloc(n*sizeof(char));
  // if (!ch1) error...; return NULL;

  // any kind of check missing:
  // are i, j ok?
  // is n > 0... ch[i] is "inside" the string?...
  while(k<n)
    {
      ch1[k]=ch[i];
      i++;k++;
    }

  return ch1;
}

int main(int argc, char const *argv[]) {

//Imprime palindromo
// int i,j,result, length;
char string[] = "no se que hacer",newstring[50];
//
// length = strlen(string);
// for(i=0,j=0;i<length;i++)
//     if (string[i] != ' ')
//     {
//         newstring[j] = string[i];
//         j++;
//     }
// newstring[j] = '\0';
char newstring = screen(string);
int length = strlen(newstring);

result = palindromo(newstring, length);
printf("Palindromo %d\n", result);

return status;
}



// #include<stdio.h>
//
// #define MAX 100
//
// int getMaxElement(int []);  // takes array of int as parameter
// int size;
//
// int main()
// {
//     printf("\n\n\t\tStudytonight - Best place to learn\n\n\n");
//     int arr[MAX], max, i;
//     printf("\n\nEnter the size of the array: ");
//     scanf("%d", &size);
//     printf("\n\nEnter %d elements\n\n", size);
//
//     for(i = 0; i < size; i++)
//     {
//         scanf("%d", &arr[i]);
//     }
//
//     max = getMaxElement(arr);   // passing the complete array as parameter
//     printf("\n\nLargest element of the array is %d\n\n", max);
//     printf("\n\n\t\t\tCoding is Fun !\n\n\n");
//     return 0;
// }
//
// int getMaxElement(int a[])
// {
//     static int i = 0, max =- 9999;  // static int max=a[0] is invalid
//     if(i < size)   // till the last element
//     {
//         if(max < a[i])
//         max = a[i];
//
//         i++;    // to check the next element in the next iteration
//         getMaxElement(a);   // recursive call
//     }
//     return max;
// }
