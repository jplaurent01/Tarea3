#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <string.h>
//#include "stdafx.h"

//Funcion suma
int sum (int N){
//Si N es igual a 1 retorna 1
//Caso contrario suma N + N-1
if (N == 1) {
  return N;
}
  return N + sum(N-1);
}

void print(int array[], int init, int size)
{
//Caso baso
if(init >= size)
    return;
//Imprime el elemento actual
printf("%d, ", array[init]);
//Se realiza impresion siguiente
//elemento
print(array, init + 1, size);
}

int digit(int N){
//Caso base, cuenta 1 cuando
//ya no es divisible
if(N < 10)
    return 1;
else{
//suma un elemento
//por cada digito leido
  return 1 + digit(N/10);
}
}
//Funcion determina elemento mayor de un array
int max(int a[], int n)
{
  //Si se cumple condicion
  //retorna primer elemento array
    if (n == 1)
        return a[0];
    --n;
    //llamado recursivo en Caso
    //de no estar en ultimo elemento
    return max(a + (a[0] < a[n]), n);
}

int prime(float n) {
//Numero igual 2 retorna primo
if ((int)n == 2)
    return 1;
//retorna no primo
if ((int)(1/(n - (int)n)) % (int)n == 0)
    return 0;
//retorna llamado recursivo
if (n / (int)n == 1)
//Almacena parametro original a posciones decimales
    return prime(n-1 + 1/n);
//Llamado recursivo
    return prime(n-1);
}

int palindromo(char *string, int size)
{
    if (size <= 0)
        return 1;
    else if (string[0] == string[size - 1])
        return palindromo(&string[1], size - 2);
    else
        return 0;
}


int main(int argc, char const *argv[]) {
//Variables
int status = 0;
int N = 5;
int size = 4;
int array[] = {1, 2, 3, 4};
int Num = 150;
//Imprime suma
printf("Suma hasta hasta 5\n");
printf("suma %d\n", sum(N));

printf("Imprimir elementos del array {1, 2, 3, 4}\n");
//Imprime elementos array
print(array, 0, size);

printf("\nCantidad de digitos de 150\n");
//Imprime cantidad de digitos
printf("%d\n", digit(Num));

//Imprime elemento mayor
printf("Numero mayor de {4}\n");
int array0[] = {4};
int big_1 = max(array0, 1);
printf("Mayor %d\n", big_1);

printf("Numero mayor de {11, 3, 11, 5, 4, 12 }\n");
 int array1[] = {11, 3, 11, 5, 4, 12 };
 int big_2 = max(array1, 6);   // passing the complete array as parameter
 printf("Mayor %d\n", big_2);
 //

printf("Numero mayor de {4, 3, 10, 5}\n");
 int array2[] = {4, 3, 10, 5};
 int big = max(array2,4);   // passing the complete array as parameter
 printf("Mayor %d\n", big);

// //Imprime Primo
printf("Numero primo de 4\n");
printf("%d\n", prime(4));
printf("Numero primo de 5\n");
printf("%d\n", prime(5));

//Imprime palindromo
printf("Palabra  de oso\n");
int i,j,result, length;
char string[] = "oso",newstring[50];

length = strlen(string);
//Se utiliza en caso de encontrar espacios
for(i=0,j=0;i<length;i++)
    if (string[i] != ' ')
    {
        newstring[j] = string[i];
        j++;
    }
newstring[j] = '\0';
length = strlen(newstring);

result = palindromo(newstring, length);
printf("Palindromo %d\n", result);

/////////////////////////////////////
printf("Palabra  de casa\n");
int i_0,j_0,result_0, length_0;
char string_0[] = "casa",newstring_0[50];

length_0 = strlen(string_0);
//Se utiliza en caso de encontrar espacios
for(i_0=0,j_0=0;i_0<length_0;i_0++)
    if (string_0[i_0] != ' ')
    {
        newstring_0[j_0] = string_0[i_0];
        j_0++;
    }
newstring_0[j_0] = '\0';
length_0 = strlen(newstring_0);

result_0 = palindromo(newstring_0, length_0);
printf("Palindromo %d\n", result_0);
//////////////////////////////////////////////////
printf("Palabra de salas\n");
int i_1,j_1,result_1, length_1;
char string_1[] = "salas",newstring_1[50];

length_1 = strlen(string_1);
//Se utiliza en caso de encontrar espacios
for(i_1=0,j_1=0;i_1<length_1;i_1++)
    if (string_1[i_1] != ' ')
    {
        newstring_1[j_1] = string_1[i_1];
        j_1++;
    }
newstring_1[j_1] = '\0';
length_1 = strlen(newstring_1);

result_1 = palindromo(newstring_1, length_1);
printf("Palindromo %d\n", result_1);
//////////////////////////////////////////////
printf("Palabra de otto\n");
int i_2,j_2,result_2, length_2;
char string_2[] = "otto",newstring_2[50];

length_2 = strlen(string_2);
//Se utiliza en caso de encontrar espacios
for(i_2=0,j_2=0;i_2<length_2;i_2++)
    if (string_2[i_2] != ' ')
    {
        newstring_2[j_2] = string_2[i_2];
        j_2++;
    }
newstring_2[j_2] = '\0';
length_2 = strlen(newstring_2);

result_2 = palindromo(newstring_2, length_2);
printf("Palindromo %d\n", result_2);
//////////////////////////////////////////
printf("Palabra amor a roma\n");
int i_3,j_3,result_3, length_3;
char string_3[] = "amor a roma",newstring_3[50];

length_3 = strlen(string_3);
//Se utiliza en caso de encontrar espacios
for(i_3=0,j_3=0;i_3<length_3;i_3++)
    if (string_3[i_3] != ' ')
    {
        newstring_3[j_3] = string_3[i_3];
        j_3++;
    }
newstring_3[j_3] = '\0';
length_3 = strlen(newstring_3);

result_3 = palindromo(newstring_3, length_3);
printf("Palindromo %d\n", result_3);
/////////////////////////////////////////////
printf("Palabra no se que hacer\n");
int i_4,j_4,result_4, length_4;
char string_4[] = "no se que hacer",newstring_4[50];

length_4 = strlen(string_4);
//Se utiliza en caso de encontrar espacios
for(i_4=0,j_4=0;i_4<length_4;i_4++)
    if (string_4[i_4] != ' ')
    {
        newstring_4[j_4] = string_4[i_4];
        j_4++;
    }
newstring_4[j_4] = '\0';
length_4 = strlen(newstring_4);
result_4 = palindromo(newstring_4, length_4);
printf("Palindromo %d\n", result_4);

//////////////////////////////////////////
printf("Palabra Hola Mundo\n");
int i_5,j_5,result_5, length_5;
char string_5[] = "Hola Mundo",newstring_5[50];

length_5 = strlen(string_5);
//Se utiliza en caso de encontrar espacios
for(i_5=0,j_5=0;i_5<length_5;i_5++)
    if (string_5[i_5] != ' ')
    {
        newstring_5[j_5] = string_5[i_5];
        j_5++;
    }
newstring_5[j_5] = '\0';
length_5 = strlen(newstring_5);

result_5 = palindromo(newstring_5, length_5);
printf("Palindromo %d\n", result_5);


return status;
}
