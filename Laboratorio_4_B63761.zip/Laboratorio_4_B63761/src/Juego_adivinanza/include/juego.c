#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include "juego.h"

int printRandoms(int lower, int upper)
{
int num = (rand() %
(upper - lower + 1)) + lower;
return num;
}

//determina si el usuario acerto o no
bool flag(int num, int rand){
if (num == rand){
  return true;
  }
else{
  return false;
  }
}

//Determina los casos de frio, tibio, caliente
int cases(bool flag, int num, int rand, int min, int max){
if (flag == true){
  printf("Caliente, Gano\n");
  return num;
  }

    else if (num < rand-1 || num > rand+1){
        printf("Frio\n");
        return num;
    }

    else if (num == rand-1 || num == rand+1){
        printf("Tibio\n");
        return num;
    }

}
