#if !defined(FUNCTIONS)
#define FUNCTIONS
//Declaracion de las funciones
int printRandoms(int lower, int upper);
bool flag(int num, int rand);
int cases(bool flag, int num, int rand, int min, int max);

#endif //FUNCTIONS
