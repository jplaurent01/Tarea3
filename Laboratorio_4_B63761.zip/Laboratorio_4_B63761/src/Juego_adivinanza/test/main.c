#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include "include/juego.h"

int main(int argc, char const *argv[]) {
int status = 0;
if (argc == 3) {

  //si se reciben un unico numero se ejecuata
  //el codigo
  //caso contrario envia un ERROR

  //intervalo por medio de dos argumentos de lınea de comandos.
  int min = atoi(argv[1]);
  int max = atoi(argv[2]);
  int num = 0 ;
  // N es igual a tama˜no del intervalo definido al inicio entre 3
  int N = ((max - min) + 1)/3;
  int size = 0;
  //int random = RandomNumber(min, max) ;
  // Use current time as
  // seed for random generator
  srand(time(0));
  int random = printRandoms(min, max);
  printf("Random : %d\n", random);
  if ((max > min) && (max!=min) && max > 0 && min > 0){

  //Pedir numero a ususario
  printf("Ingrese un numero ");
  scanf("%d", &num);
  //Llamados a funciones
  bool signal = flag(num, random);
  int det = cases(signal, num, random, min, max);
  while (signal == false && (size < N - 1)) {
  int num = 0;
  int det = 0;
  // bool signal = false;
  //solicita nuevo numero
  printf("Ingrese un numero ");
  scanf("%d", &num);
  //Nuevos llamados
  //Determina si el numero es igual a random, false si no son iguales, true sale del while
  signal = flag(num, random);
  det = cases(signal, num, random, min, max);
  size += 1;
  }

  }
  else {
  printf("INTERVALO INVALIDO\n");
  return status;
  }
  	return status;

}
else{
printf("Ingrese unicamente 2 intervalos");
return status;
  }
}
